

// speedvergleich 

// ECMA 5 und 6
document.querySelector("#id")
document.querySelectorAll(".rot")

// vorher?
// keine css - Syntax
document.getElementById("id")         // ->           das schnellste 
document.getElementsByTagName("p")
document.getElementsByClassName("fett, rot")