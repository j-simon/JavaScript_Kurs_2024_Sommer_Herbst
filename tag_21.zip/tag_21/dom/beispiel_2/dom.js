'use strict'
let document ={

    html: {
        head: null ,
        body: null
    }
}