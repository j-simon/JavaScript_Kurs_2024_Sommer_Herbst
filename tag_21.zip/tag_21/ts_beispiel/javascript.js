'use strict '

zahl=10
zahl="oh, jetzt ein Text"